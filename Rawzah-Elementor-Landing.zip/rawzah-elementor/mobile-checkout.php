<?php
if (!defined('ABSPATH')) { exit; }

/** Optional domestic COD preset. Enabled explicitly for one selected product only. */
function rwe_mobile_mode() {
    if (get_option('rwe_mobile_checkout') !== 'yes' || !function_exists('WC') || !WC()->cart) { return false; }
    $id = (int) get_option('rwe_product_id');
    $items = WC()->cart->get_cart();
    if (!$id || count($items) !== 1) { return false; }
    $item = reset($items);
    return (int) $item['product_id'] === $id || (!empty($item['variation_id']) && (int) $item['variation_id'] === $id);
}

add_filter('woocommerce_checkout_fields', function ($fields) {
    if (!rwe_mobile_mode()) { return $fields; }
    $first = $fields['billing']['billing_first_name'] ?? array('type' => 'text');
    $phone = $fields['billing']['billing_phone'] ?? array('type' => 'tel');
    $address = $fields['billing']['billing_address_1'] ?? array('type' => 'text');
    $first = array_merge($first, array('label' => 'আপনার নাম', 'placeholder' => 'সম্পূর্ণ নাম লিখুন', 'required' => true, 'class' => array('form-row-wide'), 'priority' => 10));
    $phone = array_merge($phone, array('type' => 'tel', 'label' => 'মোবাইল নম্বর', 'placeholder' => '01XXXXXXXXX', 'required' => true, 'class' => array('form-row-wide'), 'priority' => 20));
    $address = array_merge($address, array('type' => 'textarea', 'label' => 'পূর্ণ ঠিকানা', 'placeholder' => 'বাসা, রোড, এলাকা, থানা ও জেলা লিখুন', 'required' => true, 'class' => array('form-row-wide'), 'priority' => 30));
    $fields['billing'] = array('billing_first_name' => $first, 'billing_phone' => $phone, 'billing_address_1' => $address, 'billing_country' => array('type' => 'hidden', 'required' => true, 'default' => 'BD', 'priority' => 40));
    $fields['shipping'] = array();
    $fields['order'] = array();
    return $fields;
}, 9999);

add_filter('woocommerce_cart_needs_shipping_address', function ($needed) { return rwe_mobile_mode() ? false : $needed; }, 9999);
add_filter('woocommerce_checkout_posted_data', function ($data) {
    if (!rwe_mobile_mode()) { return $data; }
    $data['billing_country'] = 'BD';
    $data['shipping_country'] = 'BD';
    $data['ship_to_different_address'] = false;
    if (isset($data['billing_phone'])) { $data['billing_phone'] = strtr($data['billing_phone'], array('০'=>'0','১'=>'1','২'=>'2','৩'=>'3','৪'=>'4','৫'=>'5','৬'=>'6','৭'=>'7','৮'=>'8','৯'=>'9')); }
    return $data;
}, 9999);

add_filter('woocommerce_cart_shipping_packages', function ($packages) {
    if (!rwe_mobile_mode()) { return $packages; }
    foreach ($packages as &$package) {
        // The preset is domestic; the customer explicitly selects a delivery area.
        $package['destination']['country'] = 'BD';
    }
    unset($package);
    return $packages;
}, 9999);
add_filter('woocommerce_cart_ready_to_calc_shipping', function ($ready) { return rwe_mobile_mode() ? true : $ready; }, 9999);
add_filter('woocommerce_package_rates', function ($rates, $package) {
    if (!rwe_mobile_mode()) { return $rates; }
    return array(
        'rawzah_inside' => new WC_Shipping_Rate('rawzah_inside', 'ঢাকার ভিতরে', 60, array(), 'rawzah_delivery'),
        'rawzah_outside' => new WC_Shipping_Rate('rawzah_outside', 'ঢাকার বাইরে', 100, array(), 'rawzah_delivery'),
    );
}, 9999, 2);

add_action('admin_post_rwe_mobile_settings', function () {
    if (!current_user_can('manage_options')) { wp_die('Administrator access required.'); }
    check_admin_referer('rwe_mobile_settings');
    $id = isset($_POST['product_id']) ? absint($_POST['product_id']) : 0;
    $enabled = isset($_POST['mobile_enabled']) && $_POST['mobile_enabled'] === 'yes';
    if ($enabled && (!$id || !function_exists('wc_get_product') || !wc_get_product($id))) { wp_die('Select a valid WooCommerce product ID first.'); }
    if ($enabled && get_option('woocommerce_enable_guest_checkout', 'yes') !== 'yes') { wp_die('Enable guest checkout in WooCommerce Accounts & Privacy first; the mobile preset does not collect an account email.'); }
    if ($enabled && wc_get_product($id)->is_virtual()) { wp_die('This oil is a physical product. Disable the product Virtual checkbox before enabling its delivery preset.'); }
    update_option('rwe_product_id', $id, false);
    update_option('rwe_mobile_checkout', $enabled ? 'yes' : 'no', false);
    if (class_exists('WC_Cache_Helper')) { WC_Cache_Helper::get_transient_version('shipping', true); }
    wp_safe_redirect(admin_url('edit.php?post_type=page&page=rwe-elementor'));
    exit;
});

function rwe_mobile_settings_form() {
    $id = (int) get_option('rwe_product_id');
    echo '<hr><h2>Optional: three-field mobile checkout</h2><p>This preset applies only when the cart contains the selected product alone. It uses name, phone and full address, with a customer-selected delivery area: Dhaka 60 / outside 100. It is for domestic Bangladesh orders. Other carts keep their existing fields and rates.</p>';
    echo '<form action="' . esc_url(admin_url('admin-post.php')) . '" method="post"><input type="hidden" name="action" value="rwe_mobile_settings">';
    wp_nonce_field('rwe_mobile_settings');
    echo '<p><label>Rawzah WooCommerce product ID <input type="number" name="product_id" min="1" value="' . esc_attr($id ?: '') . '"></label></p>';
    echo '<p><label><input type="checkbox" name="mobile_enabled" value="yes" ' . checked(get_option('rwe_mobile_checkout'), 'yes', false) . '> Enable the domestic mobile preset for this product</label></p>';
    echo '<p>Keep this plugin active while the preset is enabled. Customer email is not collected in this mode; WooCommerce still records the order and phone. Payment gateways, stock, product prices and order processing remain handled by WooCommerce/CartFlows.</p>';
    echo '<p>Enable WooCommerce guest checkout before using this preset. Customers choose the delivery area themselves; this preset does not infer it from postcodes.</p>';
    submit_button('Save mobile checkout settings');
    echo '</form>';
}
