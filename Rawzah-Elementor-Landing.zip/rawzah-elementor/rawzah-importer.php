<?php
/**
 * Plugin Name: Rawzah — Editable Elementor Importer
 * Description: Imports the Rawzah native Elementor design and bundled media. Includes a real CartFlows checkout shortcode widget; CartFlows and WooCommerce handle orders.
 * Version: 1.0.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: Rawzah
 * License: GPL-2.0-or-later
 */
if (!defined('ABSPATH')) { exit; }
require_once __DIR__ . '/mobile-checkout.php';

function rwe_import() {
    if (!current_user_can('manage_options')) {
        return new WP_Error('rwe_permission', 'Administrator access is required.');
    }
    if (!defined('ELEMENTOR_VERSION') && !is_plugin_active('elementor/elementor.php')) {
        return new WP_Error('rwe_elementor', 'Activate Elementor first, then open Pages > Rawzah Elementor and click Import.');
    }
    if (defined('ELEMENTOR_VERSION') && version_compare(ELEMENTOR_VERSION, '3.16.0', '<')) {
        return new WP_Error('rwe_version', 'Update Elementor to 3.16 or newer before importing this container-based page.');
    }
    $existing = (int) get_option('rwe_page_id');
    if ($existing && get_post($existing) && get_post_status($existing) !== 'trash') {
        return $existing;
    }
    $template = json_decode(file_get_contents(__DIR__ . '/native-template.json'), true);
    if (!is_array($template) || empty($template['content'])) {
        return new WP_Error('rwe_template', 'The bundled Elementor template is missing or invalid.');
    }
    $files = array('logo.webp', 'hero.webp', 'product.webp', 'ritual.webp', 'NotoSansBengali-Regular.ttf', 'NotoSansBengali-Bold.ttf', 'NotoSerifBengali-Bold.ttf', 'FONT-LICENSE.txt');
    foreach ($files as $file) {
        if (!is_readable(__DIR__ . '/assets/' . $file)) {
            return new WP_Error('rwe_asset', 'Missing package asset: ' . $file);
        }
    }
    $uploads = wp_upload_dir();
    if (!empty($uploads['error'])) { return new WP_Error('rwe_upload', $uploads['error']); }
    $dir = $uploads['basedir'] . '/rawzah-elementor';
    if (!wp_mkdir_p($dir)) { return new WP_Error('rwe_directory', 'Could not create the Rawzah uploads directory.'); }
    require_once ABSPATH . 'wp-admin/includes/image.php';
    require_once ABSPATH . 'wp-admin/includes/media.php';
    $map = get_option('rwe_assets', array());
    if (!is_array($map)) { $map = array(); }
    foreach ($files as $file) {
        if (isset($map[$file]) && is_file($map[$file]['path']) && (empty($map[$file]['id']) || get_post($map[$file]['id']))) { continue; }
        $filename = wp_unique_filename($dir, 'rawzah-' . $file);
        $target = $dir . '/' . $filename;
        if (!copy(__DIR__ . '/assets/' . $file, $target)) {
            return new WP_Error('rwe_copy', 'Could not copy media: ' . $file);
        }
        $url = $uploads['baseurl'] . '/rawzah-elementor/' . $filename;
        $id = 0;
        $type = wp_check_filetype($filename);
        if (preg_match('/\.(png|jpg|webp|mp4)$/i', $file)) {
            $id = wp_insert_attachment(array('post_title' => 'Rawzah ' . pathinfo($file, PATHINFO_FILENAME), 'post_status' => 'inherit', 'post_mime_type' => $type['type'], 'guid' => $url), $target, 0, true);
            if (is_wp_error($id)) { return $id; }
            $metadata = wp_generate_attachment_metadata($id, $target);
            if (is_array($metadata)) { wp_update_attachment_metadata($id, $metadata); }
            update_post_meta($id, '_wp_attachment_image_alt', $file === 'logo.webp' ? 'Rawzah' : 'রাওযাহ ব্যাথার তেল');
        }
        $map[$file] = array('id' => (int) $id, 'url' => esc_url_raw($url), 'path' => $target);
        update_option('rwe_assets', $map, false);
    }
    $resolve = function ($value) use (&$resolve, $map) {
        if (is_array($value)) {
            foreach ($value as $key => $item) { $value[$key] = $resolve($item); }
            return $value;
        }
        if (!is_string($value)) { return $value; }
        if (strpos($value, 'rw-id://') === 0) {
            $file = substr($value, 8);
            return isset($map[$file]) ? $map[$file]['id'] : 0;
        }
        return preg_replace_callback('/rw-asset:\/\/([A-Za-z0-9._-]+)/', function ($match) use ($map) {
            return isset($map[$match[1]]) ? $map[$match[1]]['url'] : $match[0];
        }, $value);
    };
    $template = $resolve($template);
    if (strpos(wp_json_encode($template), 'rw-asset:') !== false) {
        return new WP_Error('rwe_mapping', 'A bundled asset could not be mapped. Please retry the import.');
    }
    $page = wp_insert_post(array('post_title' => 'Rawzah — Elementor Editable', 'post_name' => 'rawzah-pain-relief-oil', 'post_type' => 'page', 'post_status' => 'draft', 'post_content' => ''), true);
    if (is_wp_error($page)) { return $page; }
    update_post_meta($page, '_elementor_edit_mode', 'builder');
    update_post_meta($page, '_elementor_template_type', 'wp-page');
    update_post_meta($page, '_elementor_version', defined('ELEMENTOR_VERSION') ? ELEMENTOR_VERSION : '3.16.0');
    update_post_meta($page, '_elementor_data', wp_slash(wp_json_encode($template['content'])));
    update_post_meta($page, '_elementor_page_settings', array('hide_title' => 'yes', 'template' => 'elementor_canvas'));
    update_post_meta($page, '_wp_page_template', 'elementor_canvas');
    update_post_meta($page, '_rw_native_imported', '1.0.0');
    update_option('rwe_page_id', (int) $page, false);
    rwe_save_library($template);
    if (class_exists('\Elementor\Plugin') && \Elementor\Plugin::$instance && isset(\Elementor\Plugin::$instance->files_manager)) {
        \Elementor\Plugin::$instance->files_manager->clear_cache();
    }
    return (int) $page;
}


function rwe_save_library($template) {
    $existing = (int) get_option('rwe_library_id');
    if ($existing && get_post($existing)) { return $existing; }
    $id = wp_insert_post(array('post_title' => 'Rawzah — Mobile Landing + CartFlows', 'post_type' => 'elementor_library', 'post_status' => 'publish', 'post_content' => ''), true);
    if (is_wp_error($id)) { return $id; }
    update_post_meta($id, '_elementor_edit_mode', 'builder');
    update_post_meta($id, '_elementor_template_type', 'page');
    update_post_meta($id, '_elementor_version', defined('ELEMENTOR_VERSION') ? ELEMENTOR_VERSION : '3.16.0');
    update_post_meta($id, '_elementor_data', wp_slash(wp_json_encode($template['content'])));
    update_post_meta($id, '_elementor_page_settings', array('hide_title' => 'yes', 'template' => 'elementor_canvas'));
    if (taxonomy_exists('elementor_library_type')) { wp_set_object_terms($id, 'page', 'elementor_library_type'); }
    update_option('rwe_library_id', (int) $id, false);
    return $id;
}

function rwe_activate() {
    require_once ABSPATH . 'wp-admin/includes/plugin.php';
    $result = rwe_import();
    if (is_wp_error($result)) { update_option('rwe_error', $result->get_error_message(), false); }
    else { delete_option('rwe_error'); }
}
register_activation_hook(__FILE__, 'rwe_activate');
register_deactivation_hook(__FILE__, function () {
    if (class_exists('WC_Cache_Helper')) { WC_Cache_Helper::get_transient_version('shipping', true); }
});

add_action('admin_menu', function () {
    add_submenu_page('edit.php?post_type=page', 'Rawzah Elementor', 'Rawzah Elementor', 'manage_options', 'rwe-elementor', 'rwe_admin');
});
function rwe_admin() {
    if (!current_user_can('manage_options')) { return; }
    $id = (int) get_option('rwe_page_id');
    echo '<div class="wrap"><h1>Rawzah — Editable Elementor Page</h1>';
    if ($id && get_post($id) && get_post_status($id) !== 'trash') {
        echo '<p>Your native Elementor draft and media are imported. The order area is a CartFlows Shortcode widget. Insert this design in a CartFlows Checkout step and assign your WooCommerce product.</p>';
        echo '<p><a class="button button-primary" href="' . esc_url(admin_url('post.php?post=' . $id . '&action=elementor')) . '">Edit with Elementor</a> ';
        echo '<a class="button" href="' . esc_url(get_preview_post_link($id)) . '" target="_blank" rel="noopener">Preview draft</a> ';
        echo '<a class="button" href="' . esc_url(wp_nonce_url(admin_url('admin-post.php?action=rwe_export'), 'rwe_export')) . '">Download Elementor JSON</a></p>';
        echo '<p>Template Library: Elementor → My Templates → Rawzah — Mobile Landing + CartFlows.</p>';
        echo '<p>After importing, the design and media remain even if you remove this importer. Keep this plugin active if you enable the optional three-field mobile checkout preset below. Elementor, WooCommerce and CartFlows remain required for the live checkout.</p>';
    } else {
        $error = get_option('rwe_error');
        if ($error) { echo '<p>' . esc_html($error) . '</p>'; }
        echo '<p>Activate Elementor Free 3.16+ first, then import. No Elementor Pro is needed.</p><form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="rwe_import">';
        wp_nonce_field('rwe_import');
        submit_button('Import Elementor Page + Media');
        echo '</form>';
    }
    echo '<p>The website page stays a draft. Product: রাওযাহ ব্যাথার তেল, BDT 899. Contact: 01628-817745. Assign the real product in CartFlows. The template never forces a cart total. Existing checkout fields and shipping remain unchanged unless you explicitly enable the optional mobile preset.</p>';
    rwe_mobile_settings_form();
    echo '</div>';
}
add_action('admin_post_rwe_import', function () {
    if (!current_user_can('manage_options')) { wp_die('Administrator access required.'); }
    check_admin_referer('rwe_import');
    require_once ABSPATH . 'wp-admin/includes/plugin.php';
    $result = rwe_import();
    if (is_wp_error($result)) { update_option('rwe_error', $result->get_error_message(), false); }
    else { delete_option('rwe_error'); }
    wp_safe_redirect(admin_url('edit.php?post_type=page&page=rwe-elementor'));
    exit;
});
add_action('admin_post_rwe_export', function () {
    if (!current_user_can('manage_options')) { wp_die('Administrator access required.'); }
    check_admin_referer('rwe_export');
    $id = (int) get_option('rwe_page_id');
    if (!$id || !get_post($id) || !current_user_can('edit_post', $id)) { wp_die('Imported page not found.'); }
    $data = array('version' => '0.4', 'title' => get_the_title($id), 'type' => 'page', 'page_settings' => get_post_meta($id, '_elementor_page_settings', true), 'content' => json_decode(get_post_meta($id, '_elementor_data', true), true));
    nocache_headers();
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename="rawzah-elementor.json"');
    echo wp_json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
});
