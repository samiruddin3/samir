(function(){
  function init(){
    document.querySelectorAll('.rw-page').forEach(function(root){
      if(root.dataset.rwReady)return;
      root.dataset.rwReady='true';
      const bar=root.querySelector('.rw-sticky'),hero=root.querySelector('.rw-hero'),order=root.querySelector('.rw-order');
      let heroVisible=true,orderVisible=false;
      const sync=()=>{if(bar)bar.hidden=heroVisible||orderVisible;};
      if('IntersectionObserver' in window){
        const observer=new IntersectionObserver(entries=>{entries.forEach(e=>{if(e.target===hero)heroVisible=e.isIntersecting;if(e.target===order)orderVisible=e.isIntersecting;});sync();},{threshold:0});
        if(hero)observer.observe(hero);if(order)observer.observe(order);
      }
      root.addEventListener('focusin',e=>{if(e.target.matches('input:not([type="radio"]):not([type="checkbox"]):not([type="hidden"]):not([type="submit"]):not([type="button"]):not([type="reset"]),textarea,select'))root.classList.add('rw-keyboard');});
      root.addEventListener('focusout',()=>root.classList.remove('rw-keyboard'));
      root.querySelectorAll('a[href="#rawzah-order"]').forEach(link=>link.addEventListener('click',e=>{if(!order)return;e.preventDefault();order.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'});}));
      function translateCheckout(){
        const box=root.querySelector('.rw-checkout');if(!box)return;
        const fields={billing_first_name:['আপনার নাম','সম্পূর্ণ নাম লিখুন'],billing_last_name:['নামের শেষ অংশ','নামের শেষ অংশ'],billing_phone:['মোবাইল নম্বর','01XXXXXXXXX'],billing_address_1:['পূর্ণ ঠিকানা','বাসা, রোড ও এলাকা লিখুন'],billing_address_2:['ঠিকানার অন্য তথ্য (ঐচ্ছিক)','ফ্ল্যাট বা অন্য তথ্য'],billing_city:['থানা / শহর','থানা বা শহর'],billing_state:['জেলা','জেলা'],billing_postcode:['পোস্টকোড','পোস্টকোড'],billing_email:['ইমেইল','আপনার ইমেইল ঠিকানা'],order_comments:['অর্ডারের নোট (ঐচ্ছিক)','বিশেষ কোনো নির্দেশনা থাকলে লিখুন']};
        Object.keys(fields).forEach(name=>{const input=box.querySelector('[name="'+name+'"]');if(!input)return;input.placeholder=fields[name][1];const label=input.id?box.querySelector('label[for="'+input.id+'"]'):null;if(label){const text=Array.from(label.childNodes).find(n=>n.nodeType===3);if(text)text.nodeValue=fields[name][0]+' ';}});
        const titles={'Customer information':'অর্ডারের তথ্য','Billing details':'আপনার তথ্য','Your order':'অর্ডারের হিসাব','Payment':'পেমেন্ট','Additional information':'অন্য তথ্য'};
        box.querySelectorAll('h3').forEach(h=>{const t=h.textContent.trim();if(titles[t])h.textContent=titles[t];});
        const terms={'Product':'পণ্য','Subtotal':'পণ্যের মূল্য','Shipping':'ডেলিভারি','Total':'সর্বমোট'};
        box.querySelectorAll('table.shop_table th').forEach(th=>{const value=th.textContent.trim();if(terms[value])th.textContent=terms[value];});
        const address=box.querySelector('[name="billing_address_1"]');
        if(address)address.placeholder='বাসা, রোড, এলাকা, থানা ও জেলা লিখুন';
        const coupon=box.querySelector('.woocommerce-form-coupon-toggle');
        if(coupon){
          const walker=document.createTreeWalker(coupon,NodeFilter.SHOW_TEXT);
          while(walker.nextNode()){
            const node=walker.currentNode;
            node.nodeValue=node.nodeValue.replace('Have a coupon?','কুপন আছে?').replace('Click here to enter your code','এখানে কোড দিন');
          }
        }
        const button=box.querySelector('#place_order');
        const gateway=box.querySelector('input[name="payment_method"]:checked');
        if(button&&gateway&&gateway.value==='cod'){button.textContent='অর্ডার নিশ্চিত করুন';button.dataset.value='অর্ডার নিশ্চিত করুন';}
      }
      translateCheckout();
      if(window.jQuery)window.jQuery(document.body).on('updated_checkout.rawzah',translateCheckout);
    });
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
  window.addEventListener('elementor/frontend/init',()=>{if(window.elementorFrontend)elementorFrontend.hooks.addAction('frontend/element_ready/shortcode.default',init);});
})();
