<?php
if (!defined('ABSPATH')) { exit; }

/** Apply only presentation metadata; CartFlows owns products, flow links and orders. */
function rwe_cartflows_apply($target_id) {
    $target_id = absint($target_id);
    if (!current_user_can('manage_options') || !current_user_can('edit_post', $target_id)) {
        return new WP_Error('rwe_cf_permission', 'You need permission to edit this checkout.');
    }
    $target = get_post($target_id);
    if (!$target || $target->post_type !== 'cartflows_step' || get_post_meta($target_id, 'wcf-step-type', true) !== 'checkout' || !in_array($target->post_status, array('draft', 'pending', 'private', 'publish'), true)) {
        return new WP_Error('rwe_cf_target', 'Select a CartFlows Checkout step, not a landing or thank-you step.');
    }
    if (!defined('ELEMENTOR_VERSION') || !shortcode_exists('cartflows_checkout') || !class_exists('WooCommerce')) {
        return new WP_Error('rwe_cf_plugins', 'Activate Elementor, CartFlows and WooCommerce before applying the design.');
    }
    $source_id = (int) get_option('rwe_page_id');
    $raw = $source_id ? get_post_meta($source_id, '_elementor_data', true) : '';
    $data = is_string($raw) ? json_decode($raw, true) : null;
    if (!$data || !is_array($data) || strpos($raw, '[cartflows_checkout]') === false || strpos($raw, 'rw-asset://') !== false) {
        return new WP_Error('rwe_cf_source', 'Import Visual Story v2 + All Images first.');
    }
    $new_settings = get_post_meta($source_id, '_elementor_page_settings', true);
    if (!is_array($new_settings)) { $new_settings = array(); }
    $new_settings['template'] = 'elementor_canvas';
    $new_settings['hide_title'] = 'yes';
    if (get_post_meta($target_id, '_elementor_data', true) === $raw && get_post_meta($target_id, '_wp_page_template', true) === 'elementor_canvas' && get_post_meta($target_id, '_elementor_page_settings', true) === $new_settings) {
        return array('checkout' => $target_id, 'backup' => (int) get_post_meta($target_id, '_rwe_design_backup', true), 'unchanged' => true);
    }
    $backup = wp_insert_post(array(
        'post_type' => 'elementor_library', 'post_status' => 'publish',
        'post_title' => 'Before Rawzah — ' . $target->post_title . ' — ' . current_time('Y-m-d H:i:s'),
        'post_content' => $target->post_content,
    ), true);
    if (is_wp_error($backup)) { return $backup; }
    $old_data = get_post_meta($target_id, '_elementor_data', true);
    update_post_meta($backup, '_elementor_edit_mode', 'builder');
    update_post_meta($backup, '_elementor_template_type', 'page');
    update_post_meta($backup, '_elementor_version', ELEMENTOR_VERSION);
    update_post_meta($backup, '_elementor_data', wp_slash($old_data ? $old_data : '[]'));
    update_post_meta($backup, '_elementor_page_settings', get_post_meta($target_id, '_elementor_page_settings', true));
    update_post_meta($backup, '_rwe_backup_target', $target_id);
    update_post_meta($backup, '_rwe_original_page_template', get_post_meta($target_id, '_wp_page_template', true));
    if (taxonomy_exists('elementor_library_type')) { wp_set_object_terms($backup, 'page', 'elementor_library_type'); }

    update_post_meta($target_id, '_elementor_data', wp_slash($raw));
    update_post_meta($target_id, '_elementor_edit_mode', 'builder');
    update_post_meta($target_id, '_elementor_version', ELEMENTOR_VERSION);
    update_post_meta($target_id, '_elementor_page_settings', $new_settings);
    update_post_meta($target_id, '_wp_page_template', 'elementor_canvas');
    update_post_meta($target_id, '_rwe_design_backup', $backup);
    update_post_meta($target_id, '_rwe_design_applied', RWE_DESIGN_VERSION);
    delete_post_meta($target_id, '_elementor_css');
    clean_post_cache($target_id);
    if (class_exists('\\Elementor\\Plugin') && isset(\Elementor\Plugin::$instance->files_manager)) {
        \Elementor\Plugin::$instance->files_manager->clear_cache();
    }
    return array('checkout' => $target_id, 'backup' => $backup, 'unchanged' => false);
}

function rwe_cartflows_setup_form() {
    if (!current_user_can('manage_options')) { return; }
    echo '<hr><h2>CartFlows Checkout-এ ডিজাইন বসান</h2>';
    $notice = get_transient('rwe_cf_notice_' . get_current_user_id());
    if (is_array($notice)) {
        delete_transient('rwe_cf_notice_' . get_current_user_id());
        echo '<div class="notice ' . (!empty($notice['error']) ? 'notice-error' : 'notice-success') . ' inline"><p>' . esc_html($notice['text']) . '</p></div>';
        if (!empty($notice['checkout']) && current_user_can('edit_post', $notice['checkout'])) {
            echo '<p><a class="button button-primary" href="' . esc_url(admin_url('post.php?post=' . absint($notice['checkout']) . '&action=elementor')) . '">Edit Checkout with Elementor</a></p>';
        }
    }
    if (!post_type_exists('cartflows_step') || !shortcode_exists('cartflows_checkout') || !class_exists('WooCommerce')) {
        echo '<p>Elementor, WooCommerce ও CartFlows সক্রিয় করে CartFlows-এ একটি Checkout step তৈরি করুন।</p>';
        return;
    }
    $steps = get_posts(array('post_type' => 'cartflows_step', 'post_status' => array('publish', 'draft', 'pending', 'private'), 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC', 'meta_key' => 'wcf-step-type', 'meta_value' => 'checkout'));
    $steps = array_values(array_filter($steps, function ($step) { return current_user_can('edit_post', $step->ID); }));
    if (!$steps) {
        echo '<p>CartFlows → Flows থেকে একটি Checkout step তৈরি করুন। তারপর এই পেজে ফিরুন।</p>';
        return;
    }
    echo '<p>প্রথমে Checkout step-এর Products অংশে রাওযাহর আসল WooCommerce product দিন। নিচে সেই Checkout নির্বাচন করলে বর্তমান ডিজাইনের একটি backup template তৈরি করে নতুন design বসানো হবে। Published step বাছলে তার দৃশ্যমান design এখনই বদলাবে।</p>';
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="rwe_cartflows_apply">';
    wp_nonce_field('rwe_cartflows_apply');
    echo '<p><label for="rwe-cartflows-step"><strong>CartFlows Checkout</strong></label><br><select id="rwe-cartflows-step" name="checkout_id" required><option value="">একটি Checkout নির্বাচন করুন</option>';
    foreach ($steps as $step) {
        $label = $step->post_title . ' — #' . $step->ID . ' (' . $step->post_status . ')';
        echo '<option value="' . esc_attr($step->ID) . '">' . esc_html($label) . '</option>';
    }
    echo '</select></p>';
    submit_button('এই Checkout-এ Rawzah design বসান');
    echo '</form><p>Backup: Elementor → My Templates → “Before Rawzah …”। এই কাজ product assignment, flow/thank-you links, payment settings বা step-এর publish status বদলায় না।</p>';
    echo '<p>CartFlows checkout layout: Classic / One Column। এই template-এ [cartflows_checkout] আগে থেকেই আছে; আরেকটি checkout widget যোগ করবেন না।</p>';
}

add_action('admin_post_rwe_cartflows_apply', function () {
    if (!current_user_can('manage_options')) { wp_die('Administrator access required.'); }
    check_admin_referer('rwe_cartflows_apply');
    $id = isset($_POST['checkout_id']) ? absint(wp_unslash($_POST['checkout_id'])) : 0;
    $result = rwe_cartflows_apply($id);
    if (is_wp_error($result)) {
        $notice = array('error' => true, 'text' => $result->get_error_message());
    } else {
        $notice = array('error' => false, 'checkout' => $result['checkout'], 'text' => !empty($result['unchanged']) ? 'এই Checkout-এ একই design ইতিমধ্যে আছে।' : 'ডিজাইন বসানো হয়েছে। আগের design-এর backup My Templates-এ আছে। এখন নিজের Checkout URL-এ test order দিন।');
    }
    set_transient('rwe_cf_notice_' . get_current_user_id(), $notice, 5 * MINUTE_IN_SECONDS);
    wp_safe_redirect(admin_url('edit.php?post_type=page&page=rwe-elementor'));
    exit;
});
