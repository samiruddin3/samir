TOYS LAND — ELEMENTOR-এ সরাসরি EDIT করা যায়
========================================

এই ZIP একবারের importer। এটি shortcode দিয়ে পেজ দেখায় না।
এটি সব ছবি-ভিডিও আপনার Media Library/Uploads-এ রেখে একটি আসল
Elementor draft page তৈরি করে। এরপর Elementor দিয়ে এডিট করবেন।

কীভাবে ব্যবহার করবেন
-------------------
১. আপনার WordPress-এ Elementor Free সক্রিয় রাখুন (3.16 বা নতুন)।
২. Plugins → Add New → Upload Plugin থেকে
   toys-land-native-elementor.zip আপলোড করে Activate করুন।
৩. Pages → Toys Land Elementor → Edit with Elementor চাপুন।

Elementor আগে সক্রিয় না থাকলে, সেটি সক্রিয় করে Pages → Toys Land
Elementor → Import Elementor Page + Media বাটনে চাপুন।

নতুন পেজটির নাম: Toys Land — Elementor Editable
পেজটি DRAFT থাকবে। আপনার অন্য পেজ বা homepage পরিবর্তন হবে না।
নিজে দেখে ঠিক করার পর প্রয়োজনমতো Publish করবেন।

কী কী এডিট করতে পারবেন
----------------------
ছবি/লোগো: Image widget — Replace Image দিয়ে বদলান।
হেডলাইন/শিরোনাম: Heading widget — Title বদলান।
সাধারণ লেখা: Text Editor widget।
ভিডিও: Video widget — Self Hosted video নির্বাচন করুন।
অর্ডার বাটন: Button widget — Text/Link পরিবর্তন করুন।
FAQ: Accordion widget — Title/Content বদলান।
সেকশনের অবস্থান: Elementor Structure/Navigator দিয়ে সরান।

৮টি Image, ১৭টি Heading, ২টি Video, ৩টি Button, ৬টি Text Editor
ও ১টি Accordion widget রয়েছে। ২৩টি Container দিয়ে layout করা।
Elementor Pro প্রয়োজন নেই।

শুধু অর্ডার ফর্মটি HTML widget-এ রাখা হয়েছে, যাতে Elementor Free-তেও
কাজ করে। সেখানে আপনার WhatsApp নম্বর ও delivery হিসাব দেওয়া আছে।
শুরুতে আরেকটি HTML widget-এ design CSS/local font declaration আছে।
ওই style widget মুছবেন না; custom layout styling সেখানে সংরক্ষিত।

ছবি missing হবে না কেন
---------------------
ZIP-এ hero, transparent product, logo, দুই আসল MP4, দুই video poster
এবং বাংলা font আছে। Importer এগুলো নিজের সাইটের uploads directory-তে
কপি করে এবং native Image/Video widget-এ আসল attachment ID ও URL বসায়।
কোনো YOUR_URL বসাতে হবে না।

ইমপোর্ট হওয়ার পর চাইলে এই importer deactivate/delete করতে পারেন।
Elementor plugin সক্রিয় রাখতে হবে। Page, style, form, media ও font
আপনার সাইটে থাকবে। আগের shortcode-based Toys Land plugin এই পেজের
জন্য প্রয়োজন নেই।

Elementor JSON দরকার হলে
-----------------------
Importer সক্রিয় থাকা অবস্থায় Pages → Toys Land Elementor →
Download Elementor JSON চাপুন। এটি আপনার নিজের media URL-সহ
standard Elementor JSON দেবে। সেটি Elementor → Templates → Saved
Templates → Import Templates দিয়ে ব্যবহার করতে পারবেন।

ZIP-এর native-template.json importer-এর অভ্যন্তরীণ source। সরাসরি
ওই source JSON import করবেন না: importer তার media marker-গুলোকে
আপনার সাইটের attachment ID/URL-এ বদলায়।

অর্ডার
------
মূল্য: প্রতি পিস ৳৬৯০।
ঢাকার ভিতরে ডেলিভারি ৳৬০; বাইরে ৳১০০।
ক্যাশ অন ডেলিভারি আছে।
WhatsApp: 01997063941 / 8801997063941।
ফর্মে তথ্য দিয়ে বাটন চাপলে WhatsApp মেসেজ তৈরি হবে। ক্রেতাকে Send
করতে হবে। WooCommerce-এ অর্ডার জমা হবে না; সেটির সংযোগ করা হয়নি।

প্রয়োজনীয় সীমা
--------------
WordPress 6.0+, PHP 7.4+, Elementor Free 3.16+ এবং administrator access।
আপলোড সীমা কম হলে hosting upload/post limit অন্তত 16 MB করুন।
মূল ছবি ও ভিডিও Media Library থেকে মুছবেন না।

পরীক্ষার ফল validation.json ও editor-validation.json-এ আছে।
mobile-preview.png / desktop-preview.png আসল WordPress page render।
elementor-editor-preview.png আসল Elementor editor-এর screenshot।
