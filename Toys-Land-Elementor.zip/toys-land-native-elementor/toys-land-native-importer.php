<?php
/**
 * Plugin Name: Toys Land — Editable Elementor Importer
 * Description: One-time importer: copies bundled media and creates a real editable Elementor draft page. No shortcode or ongoing plugin dependency.
 * Version: 3.0.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: Toys Land
 * License: GPL-2.0-or-later
 */
if (!defined('ABSPATH')) { exit; }

function tlne_import() {
    if (!current_user_can('manage_options')) {
        return new WP_Error('tlne_permission', 'Administrator access is required.');
    }
    if (!defined('ELEMENTOR_VERSION') && !is_plugin_active('elementor/elementor.php')) {
        return new WP_Error('tlne_elementor', 'Activate Elementor first, then open Pages > Toys Land Elementor and click Import.');
    }
    if (defined('ELEMENTOR_VERSION') && version_compare(ELEMENTOR_VERSION, '3.16.0', '<')) {
        return new WP_Error('tlne_version', 'Update Elementor to 3.16 or newer before importing this container-based page.');
    }
    $existing = (int) get_option('tlne_page_id');
    if ($existing && get_post($existing) && get_post_status($existing) !== 'trash') {
        return $existing;
    }
    $template = json_decode(file_get_contents(__DIR__ . '/native-template.json'), true);
    if (!is_array($template) || empty($template['content'])) {
        return new WP_Error('tlne_template', 'The bundled Elementor template is missing or invalid.');
    }
    $files = array('logo.png', 'hero.png', 'product.png', 'poster-1.jpg', 'poster-2.jpg', 'demo-1.mp4', 'demo-2.mp4', 'NotoSansBengali-Regular.ttf', 'NotoSansBengali-Bold.ttf', 'FONT-LICENSE.txt');
    foreach ($files as $file) {
        if (!is_readable(__DIR__ . '/assets/' . $file)) {
            return new WP_Error('tlne_asset', 'Missing package asset: ' . $file);
        }
    }
    $uploads = wp_upload_dir();
    if (!empty($uploads['error'])) { return new WP_Error('tlne_upload', $uploads['error']); }
    $dir = $uploads['basedir'] . '/toys-land-elementor';
    if (!wp_mkdir_p($dir)) { return new WP_Error('tlne_directory', 'Could not create the Toys Land uploads directory.'); }
    require_once ABSPATH . 'wp-admin/includes/image.php';
    require_once ABSPATH . 'wp-admin/includes/media.php';
    $map = get_option('tlne_assets', array());
    if (!is_array($map)) { $map = array(); }
    foreach ($files as $file) {
        if (isset($map[$file]) && is_file($map[$file]['path']) && (empty($map[$file]['id']) || get_post($map[$file]['id']))) { continue; }
        $filename = wp_unique_filename($dir, 'toys-land-' . $file);
        $target = $dir . '/' . $filename;
        if (!copy(__DIR__ . '/assets/' . $file, $target)) {
            return new WP_Error('tlne_copy', 'Could not copy media: ' . $file);
        }
        $url = $uploads['baseurl'] . '/toys-land-elementor/' . $filename;
        $id = 0;
        $type = wp_check_filetype($filename);
        if (preg_match('/\.(png|jpg|mp4)$/i', $file)) {
            $id = wp_insert_attachment(array('post_title' => 'Toys Land ' . pathinfo($file, PATHINFO_FILENAME), 'post_status' => 'inherit', 'post_mime_type' => $type['type'], 'guid' => $url), $target, 0, true);
            if (is_wp_error($id)) { return $id; }
            $metadata = wp_generate_attachment_metadata($id, $target);
            if (is_array($metadata)) { wp_update_attachment_metadata($id, $metadata); }
            update_post_meta($id, '_wp_attachment_image_alt', $file === 'logo.png' ? 'Toys Land' : 'Quick Push Game');
        }
        $map[$file] = array('id' => (int) $id, 'url' => esc_url_raw($url), 'path' => $target);
        update_option('tlne_assets', $map, false);
    }
    $resolve = function ($value) use (&$resolve, $map) {
        if (is_array($value)) {
            foreach ($value as $key => $item) { $value[$key] = $resolve($item); }
            return $value;
        }
        if (!is_string($value)) { return $value; }
        if (strpos($value, 'tl-id://') === 0) {
            $file = substr($value, 8);
            return isset($map[$file]) ? $map[$file]['id'] : 0;
        }
        return preg_replace_callback('/tl-asset:\/\/([A-Za-z0-9._-]+)/', function ($match) use ($map) {
            return isset($map[$match[1]]) ? $map[$match[1]]['url'] : $match[0];
        }, $value);
    };
    $template = $resolve($template);
    if (strpos(wp_json_encode($template), 'tl-asset:') !== false) {
        return new WP_Error('tlne_mapping', 'A bundled asset could not be mapped. Please retry the import.');
    }
    $page = wp_insert_post(array('post_title' => 'Toys Land — Elementor Editable', 'post_name' => 'toys-land-quick-push-game', 'post_type' => 'page', 'post_status' => 'draft', 'post_content' => ''), true);
    if (is_wp_error($page)) { return $page; }
    update_post_meta($page, '_elementor_edit_mode', 'builder');
    update_post_meta($page, '_elementor_template_type', 'wp-page');
    update_post_meta($page, '_elementor_version', defined('ELEMENTOR_VERSION') ? ELEMENTOR_VERSION : '3.16.0');
    update_post_meta($page, '_elementor_data', wp_slash(wp_json_encode($template['content'])));
    update_post_meta($page, '_elementor_page_settings', array('hide_title' => 'yes', 'template' => 'elementor_canvas'));
    update_post_meta($page, '_wp_page_template', 'elementor_canvas');
    update_post_meta($page, '_tl_native_imported', '3.0.0');
    update_option('tlne_page_id', (int) $page, false);
    if (class_exists('\Elementor\Plugin') && \Elementor\Plugin::$instance && isset(\Elementor\Plugin::$instance->files_manager)) {
        \Elementor\Plugin::$instance->files_manager->clear_cache();
    }
    return (int) $page;
}

function tlne_activate() {
    require_once ABSPATH . 'wp-admin/includes/plugin.php';
    $result = tlne_import();
    if (is_wp_error($result)) { update_option('tlne_error', $result->get_error_message(), false); }
    else { delete_option('tlne_error'); }
}
register_activation_hook(__FILE__, 'tlne_activate');

add_action('admin_menu', function () {
    add_submenu_page('edit.php?post_type=page', 'Toys Land Elementor', 'Toys Land Elementor', 'manage_options', 'tlne-elementor', 'tlne_admin');
});
function tlne_admin() {
    if (!current_user_can('manage_options')) { return; }
    $id = (int) get_option('tlne_page_id');
    echo '<div class="wrap"><h1>Toys Land — Editable Elementor Page</h1>';
    if ($id && get_post($id) && get_post_status($id) !== 'trash') {
        echo '<p>The page and all media are imported. Headings, images, videos, buttons and FAQ are real Elementor widgets. The order form is an HTML widget.</p>';
        echo '<p><a class="button button-primary" href="' . esc_url(admin_url('post.php?post=' . $id . '&action=elementor')) . '">Edit with Elementor</a> ';
        echo '<a class="button" href="' . esc_url(get_preview_post_link($id)) . '" target="_blank" rel="noopener">Preview draft</a> ';
        echo '<a class="button" href="' . esc_url(wp_nonce_url(admin_url('admin-post.php?action=tlne_export'), 'tlne_export')) . '">Download Elementor JSON</a></p>';
        echo '<p>You can deactivate/delete this importer after importing. The Elementor page, styles, order form, videos and media remain in your site.</p>';
    } else {
        $error = get_option('tlne_error');
        if ($error) { echo '<p>' . esc_html($error) . '</p>'; }
        echo '<p>Activate Elementor Free 3.16+ first, then import. No Elementor Pro is needed.</p><form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="tlne_import">';
        wp_nonce_field('tlne_import');
        submit_button('Import Elementor Page + Media');
        echo '</form>';
    }
    echo '<p>Nothing is published automatically. WhatsApp orders go to 01997063941; they are not saved to WooCommerce.</p></div>';
}
add_action('admin_post_tlne_import', function () {
    if (!current_user_can('manage_options')) { wp_die('Administrator access required.'); }
    check_admin_referer('tlne_import');
    require_once ABSPATH . 'wp-admin/includes/plugin.php';
    $result = tlne_import();
    if (is_wp_error($result)) { update_option('tlne_error', $result->get_error_message(), false); }
    else { delete_option('tlne_error'); }
    wp_safe_redirect(admin_url('edit.php?post_type=page&page=tlne-elementor'));
    exit;
});
add_action('admin_post_tlne_export', function () {
    if (!current_user_can('manage_options')) { wp_die('Administrator access required.'); }
    check_admin_referer('tlne_export');
    $id = (int) get_option('tlne_page_id');
    if (!$id || !get_post($id) || !current_user_can('edit_post', $id)) { wp_die('Imported page not found.'); }
    $data = array('version' => '0.4', 'title' => get_the_title($id), 'type' => 'page', 'page_settings' => get_post_meta($id, '_elementor_page_settings', true), 'content' => json_decode(get_post_meta($id, '_elementor_data', true), true));
    nocache_headers();
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename="toys-land-elementor.json"');
    echo wp_json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
});
